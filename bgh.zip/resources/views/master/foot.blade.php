
{!! HTML::script('static/js/classie.js') !!}
{!! HTML::script('static/js/mlpushmenu.js') !!}

{!! HTML::script('static/js/main.js') !!}
{!! HTML::script('static/js/custom.min.js') !!}

@yield('extra-js')