<a href="#" id="trigger" class="menu-trigger"></a>
<header>
    <img src="{{ asset('static/img/logo_bgh.png') }}" alt="{{ siteSettings('siteName') }}">
    <!-- <a href="#" id="trigger_alias"></a> -->
</header>